import de.pseudonymisierung.mainzelliste.client.fttp.bloomfilter.RandomRecordBloomFilterGenerator;
import de.pseudonymisierung.mainzelliste.client.fttp.normalization.FieldsNormalization;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class GenerateBloomfilter {
    public static void main(String[] args) {
        // define how idat fields will be normalize
        Properties normalizationConfig = new Properties();
        normalizationConfig.put("field.firstName.transformer.0.type", "StringFieldTransformer");
        normalizationConfig.put("field.firstName.transformer.0.replacement", "{\"Dr\\\\.|Dipl\\\\.\":\"\",\"é\":\"e\",\"ä\":\"ae\",\"Ä\":\"AE\",\"ö\":\"oe\",\"Ö\":\"OE\",\"ü\":\"ue\",\"Ü\":\"UE\"}");
        normalizationConfig.put("field.firstName.transformer.0.upperCase", "true");
        normalizationConfig.put("field.firstName.transformer.0.trim", "true");
        normalizationConfig.put("field.firstName.transformer.1.allowedChars", "[A-Z\\s]");
        normalizationConfig.put("field.lastName.transformer.0.type", "StringFieldTransformer");
        normalizationConfig.put("field.lastName.transformer.0.replacement", "{\"Dr\\\\.|Dipl\\\\.\":\"\",\"é\":\"e\",\"ä\":\"ae\",\"Ä\":\"AE\",\"ö\":\"oe\",\"Ö\":\"OE\",\"ü\":\"ue\",\"Ü\":\"UE\"}");
        normalizationConfig.put("field.lastName.transformer.0.upperCase", "true");
        normalizationConfig.put("field.lastName.transformer.0.trim", "true");
        normalizationConfig.put("field.lastName.transformer.1.allowedChars", "[A-Z\\s]");

        // init field normalization
        FieldsNormalization fieldsNormalization = new FieldsNormalization(normalizationConfig);

        //define bloom filter configuration
        Properties bloomFilterConfig = new Properties();
        bloomFilterConfig.put("length", "800");
        bloomFilterConfig.put("nGramLength", "2");
        bloomFilterConfig.put("randomPositionNumber", "30");
        bloomFilterConfig.put("vocabulary", "abcdefghijkalmnoprstuvmxyzABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789");
        bloomFilterConfig.put("balanced.seed", "154866848");
        bloomFilterConfig.put("field.firstName.seed", "487484864");
        bloomFilterConfig.put("field.lastName.seed", "311296856");
        bloomFilterConfig.put("field.birthDate.seed", "897689196");
        bloomFilterConfig.put("field.gender.seed", "298767897");

        //init bloom filter generator
        RandomRecordBloomFilterGenerator bloomFilterGenerator = new RandomRecordBloomFilterGenerator(bloomFilterConfig);

        // prepare idat fields
        Map<String, String> fields = new HashMap<>();
        fields.put("firstName", "Lea");
        fields.put("lastName", "Meyer");
        fields.put("birthDate", "20011125");
        fields.put("gender", "f");

        // normalize fields
        Map<String, String> normalizedFields = fieldsNormalization.process(fields);

        // generate bloom filter
        String bloomFilter = bloomFilterGenerator.generateBalancedBloomFilter(normalizedFields).getBase64String();
        System.out.println("Bloomilter -> " + bloomFilter);
    }}
